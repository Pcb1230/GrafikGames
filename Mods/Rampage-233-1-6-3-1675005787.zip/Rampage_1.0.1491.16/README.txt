>--- Overview ----<
Rampage is a Trainer / Modification for Red Dead Redemption 2 Story Mode

Please keep in mind that this product is a WIP project that is evolving through time. It is not a finished release product where everything is working perfectly.
This is a mod that depends on research and R* Patches,
That means in general that functions have to be researched and there are certain borders and limits in what is possible and also what R* allows us to do.


>--- How to Install ---<
Extract the .zip file and put the Rampage.asi and RampageFiles into your RDR2 Directory.
Make sure you have the latest version of Alexander Blades ScriptHookRDR2 plugin (ScriptHookRDR2.dll & dinput8.dll)
If you have any issues with dinpu8.dll you can also just use version.dll from LMS to load your .asi files.
It's also requiered to use version.dll if you want content from RDO to be usable in Singleplayer

If RDR2 is installed on your main drive (C:) or you get any issues regarding not being able to save file make sure 
that your user account and the user group have the correct permissions for the game folder.


>--- Troubleshooting ---<
If you encounter any issues while loading such as "Settings.json missing" or "Hotkey.json missing", issues with loading of textures
or any other crashes on startup, try to delete the RampageFiles folder, dowload the latest version and restart RDR2.


>--- Common Questions ---<
Q: How can i disable the Prompt that shows Open F5?
A: Go into Settings->Extended UI->Disable "Open Info"

Q: How can i get out of creator mode?
A: Creator mode toggles when you press Ctrl + C on Keyboard you can disable this in Settings->Hotkey Manager-> Disable "Creator Hotkey"

Q: I can't move and I have a cursor on my screen!
A: You may toggled cursor mode, that happens when you press X you can either change the Key in Settings->Hotkey Manager-> "Cursor Key" or disable it completly.


>--- Known issues ---<
Options that access RDR`s entity pools like Local Peds & Local Vehicle options, Black hole etc. tend to crash if there are to many entites.
To prevent crashing because of too many spawned objects try to delete old ones first and free the memory by deleting world vehicles / peds.


>--- Important Things ---<
If you want to change a specific hotkey in the trainer you can change it in the Hotkey Manager under settings,
just click on the Option and enter your new hotkey inside the window.

Log files are stored in RampageFiles/Logs if you have any issues you may want to look into these files.

If you make any changes like changing the colors or other settings in order to save them you need to manually save them
under Settings -> Load / Save.


>--- Issues and Bug Reporting ---<
If you encounter any issues or bugs or your game crashes you can submit a bug report.
For a bug report please provide some general information like What options you used, what other mods you used
did you load any savegame?, did you played any missions or just free play? You can always find a Log inside the Rampagefiles folder in the subfolder Logs.
If you encounter any crashes you can enable Advanced Logging on version 1.3.5 and higher (Settings->Debug) you can then submit your log file to make it easier to track down issues.
w

>--- Controls ---<
Rampage supports both Keyboard & Gamepad, Controls are:
Open Trainer = F5
Move Up = Arrow Key up or Numpad8
Move Down Arrow Key down or Numpad2
Move on Numerical Option (Number, Decimal, List) = Right/Left Arrow key or Numpad4 and Numpad6
Move Back = Delete Key or Numpad0
Select = Enter Key or Numpad5


>--- Terms & Rules ---<
The Software is provided "As Is", without warranty of any kind.
The Software is completely free and it's forbidden to sell or use it in any commercial way.
You are not allowed to redistribute this software without permission.
You are not allowed to modify or reverse code as well as debugging / patching
You take full responsibility for your actions using this product.
Software support may be stopped at any time without any reason.
This terms may be updated at any time without any reason.

>--- Credits ---<

RDR2 Modding Resources
-> alloc8or Native DB
-> Alexander Blade For ScriptHookRDR2
-> rdr2mods
-> RedM


>--- Startup Arguments ---<
-> -rampage_dbg // Opens the debug console upon startup
-> -rampage_nmh // disables minhook
-> -rampage_docfm // Switches the main folder location to Documens/Rockstar Games/Red Dead Redemption 2

>--- Changelog ---<

Version 1.6.3

-> Added Experimental Script Patcher
-> Added Option to set the maximum visible options
-> Added toggle to enable alternative ink drawing for menu
-> Added two missing horses to miscellaneous tab
-> Added more train configs to train creator
-> Added option to add own speeches
-> Added option to disable water drown/kill zones
-> Added option to quick teleport to any ipl coords from the list
-> Added an option to ped spawner to block honor and wanted influence for spawned peds
-> Improved Airwalk
-> Improved Gravity Gun
-> You can now decide to which bone you want to attach peds or objects
-> Animal Unlocks have been improved and made faster
-> Fish Unlocks will now add the uncatchable legendary channel catfish
-> Fixed an issue where "Unlock all Outfits" could break Legend of the East perks
-> Fixed an issue where after using "Guarma Hurricane Water" there would be no waves or foam
-> Fixed an issue where "Unlock all Receips" would do nothing
-> Fixed an isseu where "Unlock all Weapons" wouldn't unlock a few weapons
-> Fixed an issue where markers wouldn't appear on the teleport map
-> Fixed a bunch of typing mistakes
-> In this version we switched back to minhook to enhance compatibility with linux